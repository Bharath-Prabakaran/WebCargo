<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\ClassRoomModel;


class ClassroomSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $insertDetails = array(
            array('class_name'=>'A','class_capacity'=>10,'class_duration'=>1,'class_start_time'=>9,'class_end_time'=>18),
            array('class_name'=>'B','class_capacity'=>15,'class_duration'=>2,'class_start_time'=>8,'class_end_time'=>18),
            array('class_name'=>'C','class_capacity'=>7,'class_duration'=>1,'class_start_time'=>15,'class_end_time'=>22)
        );
        foreach($insertDetails as $key=>$value){
                ClassRoomModel::insert($value);
        }
    }
}
