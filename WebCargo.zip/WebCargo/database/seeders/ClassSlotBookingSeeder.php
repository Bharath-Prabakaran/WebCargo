<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\ClassRoomModel;
use App\Models\ClassSlotBookingModel;


class ClassSlotBookingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $classDetails=ClassRoomModel::get();
        if($classDetails){
            $classDetailsArray= $classDetails->toArray();
            foreach($classDetailsArray as $key=>$val){
                 $details=   $this->getSlotVariations($val['class_start_time'],$val['class_end_time'],$val['class_duration'],$val['id']);
                ClassSlotBookingModel::insert($details);
            }
        }
    }


    public function getSlotVariations($from,$to,$variation,$class_id){
        $presentSlot=0;
        $slotArray=array();
        for($i=0;$i<$to;$i++){
            $presentSlot=$from;
            $slotArray[]=array('class_slot_from'=>$from,'class_slot_to'=>$from+$variation,'class_id'=>$class_id);
            $from = $from+$variation;
            if ($from ==$to) {
                return $slotArray;
                break;
            }
            $i++;
        }

    }
}
