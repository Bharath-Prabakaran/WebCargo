<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\ClassRoomModel;
use App\Models\ClassRoomAvailabilityModel;

class ClassAvailabilitySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $availabilityArray=array(
            'A'=>array(
                'sunday'=>0,
                'monday'=>1,
                'tuesday'=>0,
                'wednesday'=>1,
                'thursday'=>0,
                'friday'=>0,
                'saturday'=>0,
            ),
            'B'=>array(
                'sunday'=>0,
                'monday'=>1,
                'tuesday'=>0,
                'wednesday'=>0,
                'thursday'=>1,
                'friday'=>0,
                'saturday'=>1,
            ),
            'C'=>array(
                'sunday'=>0,
                'monday'=>0,
                'tuesday'=>1,
                'wednesday'=>0,
                'thursday'=>0,
                'friday'=>1,
                'saturday'=>1,
            ),
        );

        foreach($availabilityArray as $key=>$val){  
            $details = ClassRoomModel::where('class_name',$key)->pluck('id');
            $val['class_id']=$details[0];
            ClassRoomAvailabilityModel::insert($val);
        }
    }
}
