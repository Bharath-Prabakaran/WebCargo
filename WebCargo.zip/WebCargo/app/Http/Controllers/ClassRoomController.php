<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Resources\ClassRoomResource;
use App\Models\ClassRoomModel;
use App\Models\ClassRoomAvailabilityModel;
use App\Models\ClassSlotBookingModel;
use App\Models\BookingDetailsModel;
use App\Http\Requests\ClassRoomRequest;
use Carbon\Carbon;


class ClassRoomController extends Controller
{    
    /**
     * index
     *
     * @return void
     */
    public function index(){
        $weekDetails = $this->getWeekDetails();
        $classDetails = ClassRoomModel::with('classRoomAvailability')->get();
        if($classDetails){

            $details =$this->getClassRoomSlotDetails($classDetails,$weekDetails);
            return $details;
        }
        return [];
    }
    
    /**
     * getWeekDetails
     *
     * @return void
     */
    public function getWeekDetails(){
        $weekDays=['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];
        $StartDay = date('Y-m-d', strtotime("sunday -1 week"));
        $weekDetails=array();
        foreach($weekDays as $key=>$val){
            $weekDetails[$val]=$StartDay;
            $StartDay = date('Y-m-d',strtotime($StartDay. '+1 day'));
        }
        return $weekDetails;
    }
      
    /**
     * getClassRoomSlotDetails
     *
     * @param  mixed $classVal
     * @param  mixed $week_details
     * @return void
     */
    public function getClassRoomSlotDetails($classVal,$week_details){
        foreach($classVal as $classValKey=> $classValDetails){
                $class_max_capacity= $classValDetails['class_capacity'];
                $class_name= $classValDetails['class_name'];
                foreach ($week_details as $key=>$val) {
                    $slotDetails=[];
                    $weekExists= ClassRoomAvailabilityModel::where($key, '1')->where('class_id',$classValDetails['id'])->exists();
                    if ($weekExists) {
                        $class_slot_details =ClassSlotBookingModel::withCount('bookingDetails')->where('class_id', $classValDetails['id'])->get();
                        foreach ($class_slot_details as $key=>$slotVal) {
                            $slotDetails[]= 'Slot From '.$slotVal['class_slot_from'].' - '.$slotVal['class_slot_to'].' has '.($class_max_capacity-$slotVal['booking_details_count']).' slots available';
                        }
                        $classAvailability[$val]['ClassRoom '.$class_name]=$slotDetails;
                    } else {
                        $classAvailability[$val]['ClassRoom '.$class_name]=null;
                    }
                }
               

        }
        return $classAvailability;
            
    }
    
    /**
     * bookClass
     *
     * @param  mixed $request
     * @return void
     */
    public function bookClass(ClassRoomRequest $request){
        $classDetails= ClassRoomModel::where('class_name',$request->input('class'))->first();
        $class_slot_details =ClassSlotBookingModel::withCount('bookingDetails')
        ->where('class_id', $classDetails->id)
        ->where('class_slot_from',$request->input('slot_from'))
        ->where('class_slot_to',$request->input('slot_to'))
        ->first();
        if($class_slot_details){
            if( ($classDetails->class_capacity - $class_slot_details->booking_details_count) > 0){
                    $slot_id = $class_slot_details->id;
                    BookingDetailsModel::insert(array('class_id'=>$classDetails->id,'slot_id'=>$slot_id,'user_id'=>'2121'));
                    return 'Booking Done';
            }else{
                    return 'Requested slots are not available for requested date';
            }
                
        }else{
            return 'No available Slots Found';
        }
    }
    
    /**
     * cancelBooking
     *
     * @param  mixed $request
     * @return void
     */
    public function cancelBooking(ClassRoomRequest $request){
            $classDetails= ClassRoomModel::where('class_name',$request->input('class'))->first();
            $user_id=$request->input('user');
            $class_slot_details =ClassSlotBookingModel::where('class_slot_from',$request->input('slot_from'))
            ->where('class_slot_to',$request->input('slot_to'))->where('class_id',$classDetails->id)
            ->first();
            $booking_details= BookingDetailsModel::where('user_id',$user_id)->where('class_id',$classDetails->id)->where('slot_id',$class_slot_details->id)->first();

            if($booking_details){  
            $new_time = date('Y-m-d H:i:s', strtotime($booking_details->booked_on.'+24 hours'));
                if (Carbon::now()->timestamp > strtotime($new_time)) {
                    return 'Cancellation Time Period Expired';
                } else {
                        BookingDetailsModel::where('user_id', $user_id)->where('class_id', $classDetails->id)->where('slot_id', $class_slot_details->id)->delete();
                    return 'Cancellation Done';

                }
            }else{
                return "No slot Booking Details available";
            } 
    }

    
}
